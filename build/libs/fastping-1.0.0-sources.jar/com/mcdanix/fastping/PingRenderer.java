package com.mcdanix.fastping;

import com.mcdanix.fastping.api.PingManager;
import com.mcdanix.fastping.api.PingMarker;
import com.mcdanix.fastping.api.PingRenderProvider;
import com.mcdanix.fastping.api.PingRenderSpec;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_1068;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_640;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class PingRenderer {

    private static final List<PingRenderProvider> PROVIDERS = new CopyOnWriteArrayList<>();
    private static volatile List<ExtractedPing> extractedPings = List.of();

    private static final float HEAD_MIN_X = (12f - 16f) / 32f; // -0.125
    private static final float HEAD_MAX_X = (19f - 16f) / 32f; // +0.09375

    private static final float HEAD_MAX_Y = (16f -  5f) / 32f; // +0.34375
    private static final float HEAD_MIN_Y = (16f - 12f) / 32f; // +0.125

    private static final float FACE_U1 = 8f / 64f,  FACE_V1 = 8f / 64f;
    private static final float FACE_U2 = 16f / 64f, FACE_V2 = 16f / 64f;
    private static final float HAT_U1  = 40f / 64f, HAT_V1  = 8f / 64f;
    private static final float HAT_U2  = 48f / 64f, HAT_V2  = 16f / 64f;

    private record ExtractedPing(
            class_243 pos,
            PingRenderSpec spec,
            int pinColorArgb,
            int headColorArgb,
            class_2960 skinTexture
    ) {}

    private PingRenderer() {}

    public static void registerRenderProvider(PingRenderProvider provider) {
        if (provider != null) {
            PROVIDERS.add(provider);
        }
    }

    public static void init() {
        WorldRenderEvents.END_EXTRACTION.register(PingRenderer::extract);
        WorldRenderEvents.END_MAIN.register(PingRenderer::render);
    }

    private static void extract(WorldExtractionContext ctx) {
        var pings = PingManager.getPings();
        if (pings.isEmpty()) {
            extractedPings = List.of();
            return;
        }

        class_310 mc = class_310.method_1551();
        long now = System.currentTimeMillis();
        List<ExtractedPing> list = new ArrayList<>(pings.size());

        for (PingMarker marker : pings) {
            long age = now - marker.createdAt();
            long remain = PingManager.PING_LIFETIME_MS - age;
            if (remain <= 0L) continue;

            float fade = remain < PingManager.PING_FADE_MS
                    ? Math.max(0f, (float) remain / PingManager.PING_FADE_MS)
                    : 1f;

            int argb = marker.color();
            int baseAlpha = (argb >> 24) & 0xFF;
            int finalAlpha = Math.round(baseAlpha * fade);

            int pinArgb  = (finalAlpha << 24) | (argb & 0x00FFFFFF);
            int headArgb = (finalAlpha << 24) | 0x00FFFFFF;

            PingRenderSpec spec = null;
            for (PingRenderProvider provider : PROVIDERS) {
                spec = provider.getRenderSpec(marker, age, fade);
                if (spec != null) break;
            }
            if (spec == null) {
                spec = PingRenderSpec.DEFAULT;
            }

            class_2960 skinTex = resolvePlayerSkin(mc, marker.authorName());
            list.add(new ExtractedPing(marker.pos(), spec, pinArgb, headArgb, skinTex));
        }

        extractedPings = list;
    }

    private static class_2960 resolvePlayerSkin(class_310 mc, String authorName) {
        if (mc.method_1562() != null && authorName != null) {
            class_640 entry = mc.method_1562().method_2874(authorName);
            if (entry != null) {
                return entry.method_52810().comp_1626().comp_3627();
            }
        }
        return class_1068.method_4649();
    }
    public static void render(WorldRenderContext ctx) {
        List<ExtractedPing> pings = extractedPings;
        if (pings.isEmpty()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_4587 matrices = ctx.matrices();
        class_4597 consumers = ctx.consumers();
        if (matrices == null || consumers == null) return;

        class_243 camPos = ctx.worldState().field_63082.field_63078;
        Quaternionf camRot = ctx.worldState().field_63082.field_63081;
        int light = class_765.field_32767;

        for (ExtractedPing ping : pings) {
            PingRenderSpec s = ping.spec;
            float size = s.size();
            float half = size * 0.5f;

            matrices.method_22903();
            matrices.method_22904(ping.pos.field_1352 - camPos.field_1352, ping.pos.field_1351 - camPos.field_1351, ping.pos.field_1350 - camPos.field_1350);
            matrices.method_22907(camRot);

            Matrix4f mat = matrices.method_23760().method_23761();

            class_1921 pinLayer = class_12249.method_76028(s.texture());
            class_4588 pinVc = consumers.method_73477(pinLayer);

            pinVc.method_22918(mat, -half, -half, 0f).method_39415(ping.pinColorArgb).method_22913(s.u1(), s.v2()).method_60803(light);
            pinVc.method_22918(mat,  half, -half, 0f).method_39415(ping.pinColorArgb).method_22913(s.u2(), s.v2()).method_60803(light);
            pinVc.method_22918(mat,  half,  half, 0f).method_39415(ping.pinColorArgb).method_22913(s.u2(), s.v1()).method_60803(light);
            pinVc.method_22918(mat, -half,  half, 0f).method_39415(ping.pinColorArgb).method_22913(s.u1(), s.v1()).method_60803(light);

            if (ping.skinTexture != null) {
                float hx1 = HEAD_MIN_X * size;
                float hx2 = HEAD_MAX_X * size;
                float hy1 = HEAD_MIN_Y * size;
                float hy2 = HEAD_MAX_Y * size;

                class_1921 headLayer = class_12249.method_76028(ping.skinTexture);
                class_4588 headVc = consumers.method_73477(headLayer);

                headVc.method_22918(mat, hx1, hy1, 0.002f).method_39415(ping.headColorArgb).method_22913(FACE_U1, FACE_V2).method_60803(light);
                headVc.method_22918(mat, hx2, hy1, 0.002f).method_39415(ping.headColorArgb).method_22913(FACE_U2, FACE_V2).method_60803(light);
                headVc.method_22918(mat, hx2, hy2, 0.002f).method_39415(ping.headColorArgb).method_22913(FACE_U2, FACE_V1).method_60803(light);
                headVc.method_22918(mat, hx1, hy2, 0.002f).method_39415(ping.headColorArgb).method_22913(FACE_U1, FACE_V1).method_60803(light);

                headVc.method_22918(mat, hx1, hy1, 0.004f).method_39415(ping.headColorArgb).method_22913(HAT_U1, HAT_V2).method_60803(light);
                headVc.method_22918(mat, hx2, hy1, 0.004f).method_39415(ping.headColorArgb).method_22913(HAT_U2, HAT_V2).method_60803(light);
                headVc.method_22918(mat, hx2, hy2, 0.004f).method_39415(ping.headColorArgb).method_22913(HAT_U2, HAT_V1).method_60803(light);
                headVc.method_22918(mat, hx1, hy2, 0.004f).method_39415(ping.headColorArgb).method_22913(HAT_U1, HAT_V1).method_60803(light);
            }

            matrices.method_22909();
        }
    }

    public static void close() {
    }
}
