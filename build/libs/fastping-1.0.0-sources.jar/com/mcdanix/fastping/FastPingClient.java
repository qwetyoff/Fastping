package com.mcdanix.fastping;

import com.mcdanix.fastping.api.PingManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_268;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class FastPingClient implements ClientModInitializer {

    private static final double PING_RANGE = 100.0;
    private static boolean middleDownPrev = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(FastPingClient::onEndTick);
        PingRenderer.init();
    }


    private static void onEndTick(class_310 client) {
        PingManager.tick();

        if (client.field_1724 == null || client.field_1687 == null || client.field_1755 != null) {
            middleDownPrev = false;
            return;
        }

        long handle = client.method_22683().method_4490();
        boolean middleDown =
                GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;

        if (middleDown && !middleDownPrev) {
            onMiddleClick(client);
        }
        middleDownPrev = middleDown;
    }

    private static void onMiddleClick(class_310 client) {
        class_1657 player = client.field_1724;
        if (player == null) return;

        class_239 hit = player.method_5745(PING_RANGE, 0.0f, false);

        class_243 targetPos;
        if (hit.method_17783() == class_239.class_240.field_1333) {
            class_243 eye  = player.method_33571();
            class_243 look = player.method_5828(0.0f);
            targetPos = eye.method_1019(look.method_1021(PING_RANGE));
        } else {
            targetPos = hit.method_17784();
        }

        String name = player.method_5477().getString();
        int color = pickRadarColor(player);

        PingManager.addPing(targetPos, name, color);
    }

    private static int pickRadarColor(class_1657 player) {
        class_268 team = player.method_5781();
        if (team != null) {
            class_124 fmt = team.method_1202();
            if (fmt != null) {
                Integer rgb = fmt.method_532();
                if (rgb != null) return 0xFF000000 | rgb;
            }
        }

        String n = player.method_5477().getString();
        if (n != null && !n.isEmpty()) {
            int h = n.hashCode();
            float hue = ((h % 360) + 360) % 360 / 360.0f;
            int rgb = java.awt.Color.HSBtoRGB(hue, 0.85f, 1.0f);
            return 0xFF000000 | (rgb & 0xFFFFFF);
        }

        return 0xFFFF3030;
    }
}