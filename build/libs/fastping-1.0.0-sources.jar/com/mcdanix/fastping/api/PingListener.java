package com.mcdanix.fastping.api;

import net.minecraft.class_243;

public interface PingListener {
    void onLocalPingCreated(class_243 pos);
}