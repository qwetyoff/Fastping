package com.mcdanix.fastping.api;

import net.minecraft.class_243;

public record PingMarker(class_243 pos, String authorName, int color, long createdAt) {
}